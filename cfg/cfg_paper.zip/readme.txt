Config files used to generate the results:
------------------------------------------

Main manuscript:

- Figure 1 to 4:	run config_buoys.R (using the launch.R file)
- Figure 5: 		run config_FOB.R and config_LOG.R
			then run Sub-Routines/Alone.Comparison_FOB_types.R with
				FOLDER_NAME <- "dd5bd6a" (l36)
				FOB_TYPE1 <- "FOB" (l39)
				FOB_TYPE2 <- "LOG" (l40)

Supplementary materials:
- Supplements 3:	run config_buoys.R
- Supplements 4:	run config_FOB.R and config_LOG.R
- Supplements 5: 	same as for the main manuscript but with config_*_YFT50_R02.R
